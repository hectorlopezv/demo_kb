type SchemaType = {
  columnname: string;
  type: "number" | "string" | "boolean";
  decorators: string;
};

export type { SchemaType };
